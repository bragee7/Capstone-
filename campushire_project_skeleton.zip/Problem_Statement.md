# Problem Statement

## 1. Title

CampusHire – Smart Campus Internship & Placement Management Platform

## 2. Domain

HRTech / Education Technology

## 3. Who is the user?

- **Student** – creates a profile, searches internships, applies for opportunities, and tracks applications.
- **Company** – creates a company profile, posts internship opportunities, and manages student applications.
- **Placement Admin** – monitors students, companies, internships, applications, and placement activities.

## 4. What problem are we solving?

Students often depend on multiple channels to discover internship and placement opportunities, understand eligibility requirements, submit applications, and track progress. Companies and placement administrators also need a structured way to publish opportunities and manage applications.

This can result in scattered information, manual tracking, delayed communication, and difficulty monitoring recruitment activities.

CampusHire provides a centralized platform where students, companies, and placement administrators can manage the internship and placement workflow through role-based access and a common system.

## 5. Proposed Solution

CampusHire is a full-stack web application that centralizes campus internship and placement activities.

Students can:
- Maintain profiles
- Browse internship opportunities
- Submit applications
- Track applications

Companies can:
- Maintain company profiles
- Create internship opportunities
- Manage applications

Placement administrators can:
- Monitor users and opportunities
- Manage platform activities
- View placement-related records

## 6. Core Entities / Database Tables

- User
- Student
- Company
- Internship
- Application
- Interview
- Offer

## 7. User Roles & Permissions

### Student
- Register and login
- Manage profile
- View internships
- Apply for internships
- Track applications

### Company
- Register and login
- Manage company profile
- Create internship opportunities
- View and manage applications

### Placement Admin
- Monitor users
- Monitor opportunities
- Manage platform records
- View placement activities

## 8. Success Criteria

- Secure registration and login using JWT authentication.
- Students can view internship opportunities and submit applications.
- Companies can create and manage internship opportunities.
- Data is persisted in MySQL using Spring Data JPA/Hibernate.
- React communicates with Spring Boot through REST APIs.
- Role-based access protects functionality.
- The architecture supports future interview, offer, notification, and AI features.

## 9. Out of Scope

- Direct integration with a college's official placement management system.
- Real-time integration with external company HR systems.
- Guaranteeing an internship or job placement.
- Advanced AI recommendation functionality in the initial MVP.
- Production-scale analytics and advanced deployment features in Review-I.

## 10. Chosen Track

**Java Track**

- Backend: Java 17 + Spring Boot 3.x
- Security: Spring Security + JWT
- ORM/Data Layer: Spring Data JPA + Hibernate
- Database: MySQL 8
- Build Tool: Maven
- Testing: JUnit 5
- API Documentation: Springdoc OpenAPI / Swagger UI
- Frontend: React.js + Axios + Bootstrap/Tailwind CSS

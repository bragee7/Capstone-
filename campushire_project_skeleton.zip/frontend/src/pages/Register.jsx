function Register() {
  return (
    <div>
      <h2>Register</h2>
      <p>Registration page skeleton.</p>
    </div>
  )
}

export default Register

function Login() {
  return (
    <div>
      <h2>Login</h2>
      <p>Login page skeleton.</p>
    </div>
  )
}

export default Login

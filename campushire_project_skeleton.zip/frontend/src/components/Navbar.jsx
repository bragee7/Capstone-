function Navbar() {
  return (
    <nav>
      <strong>CampusHire</strong>
    </nav>
  )
}

export default Navbar

function App() {
  return (
    <div>
      <h1>CampusHire</h1>
      <p>Smart Campus Internship & Placement Management Platform</p>
      <p>Review-I frontend skeleton is ready.</p>
    </div>
  )
}

export default App

# CampusHire

Smart Campus Internship & Placement Management Platform.

## Project Overview

CampusHire is a full-stack platform for managing campus internship and placement activities. It provides role-based access for Students, Companies, and Placement Admins.

## Review-I MVP

1. JWT-based registration and login
2. Company creates internship
3. Student views internships
4. Student applies for internship
5. Application data is stored in MySQL

## Technology Stack

### Frontend
- React.js
- Axios
- Bootstrap / Tailwind CSS

### Backend
- Java 17
- Spring Boot 3.x
- Spring Security
- JWT
- Spring Data JPA
- Hibernate
- Maven

### Database
- MySQL 8

### Testing
- JUnit 5

### API Documentation
- Springdoc OpenAPI / Swagger UI

## Project Structure

- `backend/` - Spring Boot REST API
- `frontend/` - React frontend
- `database/` - SQL schema and seed files
- `docs/diagrams/` - Architecture and design diagrams

## Local Setup

### Prerequisites

- JDK 17+
- Maven 3.9+
- Node.js 20+
- MySQL 8+

### Backend

```bash
cd backend
mvn spring-boot:run
```

Backend runs on `http://localhost:8080`.

### Frontend

```bash
cd frontend
npm install
npm run dev
```

## Environment Variables

Copy `.env.example` and configure your local database and JWT settings.

## Database

Create a MySQL database named `campushire`, then run:

```text
database/schema.sql
```

## Status

Review-I MVP in development.

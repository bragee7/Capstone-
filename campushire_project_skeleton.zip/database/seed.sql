USE campushire;

-- Development seed data will be added after the core entities are implemented.

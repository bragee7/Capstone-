CREATE DATABASE IF NOT EXISTS campushire;

USE campushire;

-- Review-I database skeleton.
-- Tables will be implemented through JPA entities.
-- Keep this file as the database initialization reference.

# Changelog

## [0.1.0] - Review-I

### Added
- Initial CampusHire project structure
- Problem statement
- Architecture and database design folders
- Spring Boot backend skeleton
- React frontend skeleton
- MySQL database scripts
- Environment variable template

### Planned for Review-I
- JWT authentication
- Company internship creation
- Student internship browsing
- Student internship application

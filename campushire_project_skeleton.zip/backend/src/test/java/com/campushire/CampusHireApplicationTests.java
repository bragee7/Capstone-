package com.campushire;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CampusHireApplicationTests {

    @Test
    void contextLoads() {
    }
}
